<?php

namespace dev\d4y\kits\objects;

use dev\d4y\kits\manager\KitManager;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\Item;
use pocketmine\permission\Permission;
use pocketmine\permission\PermissionManager;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class Kit
{

    public const TYPE_BASIC = 1;
    public const TYPE_VIP = 2;
    public const TYPE_CRATE = 3;

    /** @var Item[] $items */
    private array $items;

    /** @var string $name */
    private string $name;

    /** @var string $description */
    private string $description;

    /** @var int $cooldown */
    private int $cooldown;

    /** @var null|string $permission */
    private ?string $permissionName;

    /** @var int $type */
    private int $type;

    /** @var Permission $permission */
    private ?Permission $permission;

    public function __construct(string $name, array $items, string $description, int $type = self::TYPE_BASIC, int $cooldown = 60, ?string $permissionName = null)
    {
        $this->name = $name;
        $this->permissionName = $permissionName;
        $this->description = $description;
        $this->cooldown = $cooldown;
        $this->type = $type;

        $this->items = $items;

        $this->init();
    }

    private function init(): void
    {
        $fileName = $this->getPath() . ".yml";
        $file = new Config($fileName, Config::YAML);

        $items = $this->itemsToConfig($this->items);

        $fields = array(
            "Name" => $this->name,
            "Description" => $this->description,
            "Type" => $this->type,
            "Permission" => $this->permission ?? "",
            "Items" => $items,
            "Cooldown" => $this->cooldown ?? 60
        );

        foreach ($fields as $field => $value) {
            if (!$file->exists($field)) {
                $file->set($field, $value);
            }
        }
        $file->save();

        if (!is_null($this->permissionName) || $this->permissionName != "") {
            $this->permission = new Permission($this->permissionName);
            PermissionManager::getInstance()->addPermission($this->permission);
            return;
        }
        $this->permission = null;
    }

    private function getPath(): string
    {
        return KitManager::get()->getKitsDirectory() . $this->name;
    }

    private function itemsToConfig(array $items): array
    {
        $return = array();

        /** @var Item $item */
        foreach ($items as $item) {
            if ($item->getId() == 0) continue;

            $fields = array(
                "CustomName" => "",
                "Id" => $item->getId(),
                "Meta" => $item->getMeta(),
                "Count" => $item->getCount(),
                "Enchantments" => array()
            );

            if ($item->hasCustomName())
                $fields["CustomName"] = $item->getCustomName();

            if ($item->hasEnchantments()) {
                $enchantments = array();
                foreach ($item->getEnchantments() as $enchantment) {
                    $enchantFields = array(
                        "Id" => EnchantmentIdMap::getInstance()->toId($enchantment->getType()),
                        "Level" => $enchantment->getLevel()
                    );
                    $enchantments[] = $enchantFields;
                }
                $fields["Enchantments"] = $enchantments;
            }

            $return[] = $fields;
        }

        return $return;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getDescription(): string
    {
        return $this->description;
    }

    public function getCooldown(): int
    {
        return $this->cooldown;
    }

    public function getType(): int
    {
        return $this->type;
    }

    public function getPermission(): ?Permission
    {
        return $this->permission;
    }

    public function getItems(): array
    {
        return $this->items;
    }

    public function verify(Player $player): bool
    {
        return is_null($this->permission) || $player->hasPermission($this->permission) ||
            $player->getServer()->isOp($player->getName());
    }

    public function giveTo(Player $player): void
    {
        if (!$this->verify($player)) {
            $player->sendMessage("§c * Você não tem permissão para pegar esse kit!");
            return;
        }

        $kitManager = KitManager::get();
        if ($kitManager->isInCooldown($this, $player)) {
            $time = $this->formatTime($kitManager->getCooldown($this, $player) - time());
            $player->sendMessage("Faltam $time para você pegar o kit!");
            return;
        }

        if (count($this->getItems()) <= 0) {
            $player->sendMessage("§a * O kit não possuí nenhum item!");
            return;
        }

        foreach ($this->getItems() as $item) {
            if ($player->getInventory()->canAddItem($item)) {
                $player->getInventory()->addItem($item);
                continue;
            }
            $player->getWorld()->dropItem($player->getPosition(), $item);
            $player->sendMessage("§e * O item {$item->getName()} x{$item->getCount()} foi dropado por que seu inventário está cheio!");
        }

        $player->sendMessage("§a * O kit foi entregue com sucesso!");
        $kitManager->addCooldown($this, $player);
    }

    public function formatTime(int $time): string
    {
        return date("z H:i:s", $time);
    }
}
