<?php

namespace dev\d4y\kits\commands;

use dev\d4y\kits\manager\KitManager;
use dev\d4y\kits\objects\Kit;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class CreateKitCommand extends PluginCommand
{

	public function __construct()
	{
		parent::__construct("createkit", "kits.createkit");
	}

	public function run(CommandSender $sender, int $argc, array $args): void
	{
		if (!$sender instanceof Player) {
			$sender->sendMessage("§c * Você não pode executar esse comando!");
			return;
		}

		if ($argc >= 1 && $args[0] == "types") {
			$sender->sendMessage("§aTypes:\n  1: Básico\n  2: VIP\n  §v3: Caixa (Em desenvolvimento)");
			return;
		}

		if ($argc < 1) {
			$sender->sendMessage("Uso: §a/createkit §7<types|nome: string> <type: int> [cooldown: int] [permissão: string] [descrição...: string]");
			return;
		}

		$nome = array_shift($args);
		$type = intval(array_shift($args)) ?? Kit::TYPE_BASIC;
		$cooldown = intval(array_shift($args)) ?? 60;
		$perm = array_shift($args) ?? null;
		$desc = trim(implode(" ", $args)) ?? "Sem descrição";
		$items = $sender->getInventory()->getContents();

		if ($type < 0 || $type > 3) {
			$sender->sendMessage("§cO tipo $type não foi encontrado, use /createkit types para uma lista de tipos!");
			return;
		}

		$kit = new Kit($nome, $items, $desc, $type, $cooldown, $perm);
		KitManager::get()->addKit($kit);
		$sender->sendMessage("§a * O kit $nome foi criado!");
	}
}
