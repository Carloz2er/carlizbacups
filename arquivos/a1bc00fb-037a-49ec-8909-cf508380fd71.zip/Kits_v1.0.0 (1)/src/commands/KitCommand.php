<?php

namespace dev\d4y\kits\commands;

use DayKoala\inventory\WindowFactory;
use DayKoala\Windowy;
use dev\d4y\kits\manager\WindowManager;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class KitCommand extends PluginCommand
{

	public function __construct()
	{
		parent::__construct("kit");
	}

	public function run(CommandSender $sender, int $argc, array $args): void
	{
		if (!$sender instanceof Player) {
			$sender->sendMessage("§c * Only players can use this command");
			return;
		}

		$window = Windowy::getWindow(WindowFactory::CHEST, "§5 - Kits - ");

		$window->clearAll();

		WindowManager::showKitTypes($window);

		$sender->setCurrentWindow($window);
	}
}
