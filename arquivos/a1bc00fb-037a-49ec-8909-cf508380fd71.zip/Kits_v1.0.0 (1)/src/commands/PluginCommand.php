<?php

namespace dev\d4y\kits\commands;

use dev\d4y\kits\Kits;
use pocketmine\command\Command;
use pocketmine\command\CommandExecutor;
use pocketmine\command\CommandSender;

abstract class PluginCommand implements CommandExecutor
{

	/** @var string $name, $permission */
	private string $name, $permission;

	/** @var Kits $plugin */
	private Kits $plugin;

	public function __construct(string $name, string $permission = "")
	{
		$this->name = $name;
		$this->permission = $permission;

		$this->plugin = Kits::get();
	}

	public function name()
	{
		return $this->name;
	}

	public function permission()
	{
		return $this->permission;
	}

	protected function plugin(): Kits
	{
		return $this->plugin;
	}

	public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
	{
		if ($this->permission != "") {
			if (!$sender->hasPermission($this->permission)) {
				$sender->sendMessage("§c * Você não tem permissão para executar esse comando.");
				return false;
			}

			$this->run($sender, count($args), $args);
			return true;
		}

		$this->run($sender, count($args), $args);
		return true;
	}

	abstract public function run(CommandSender $sender, int $argc, array $args): void;
}
