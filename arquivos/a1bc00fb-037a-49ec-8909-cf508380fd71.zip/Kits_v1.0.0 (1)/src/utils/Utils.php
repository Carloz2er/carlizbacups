<?php

namespace dev\d4y\kits\utils;

final class Utils
{
}
