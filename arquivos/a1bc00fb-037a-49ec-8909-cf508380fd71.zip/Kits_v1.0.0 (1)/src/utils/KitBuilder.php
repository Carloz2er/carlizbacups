<?php

namespace dev\d4y\kits\utils;

use dev\d4y\kits\objects\Kit;
use pocketmine\data\bedrock\EnchantmentIdMap;
use pocketmine\item\enchantment\Enchantment;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\utils\Config;

final class KitBuilder
{

    public static function createKitFromConfig(Config $config): Kit
    {
        $name = $config->get("Name");
        $desc = $config->get("Description");
        $perm = $config->get("Permission", null);
        $type = $config->get("Type", Kit::TYPE_BASIC);
        $cooldown = $config->get("Cooldown", null);
        $items = $config->get("Items", array());

        $validItems = array();
        foreach ($items as $item) {
            if (!isset($item["Id"])) continue;

            $id = intval($item["Id"]);
            $meta = $item["Meta"] ?? 0;
            $itemName = $item["CustomName"] == "" ? null : $item["CustomName"];
            $count = $item["Count"] ?? 1;

            /** @var Item $itemInstance */
            $itemInstance = ItemFactory::getInstance()->get($id, intval($meta), intval($count));

            if ($itemName) $itemInstance->setCustomName($itemName);

            if (isset($item["Enchantments"]) && is_array($item["Enchantments"])) {
                foreach ($item["Enchantments"] as $enchantment) {
                    if (!isset($enchantment["Id"])) continue;
                    $id = $enchantment["Id"];
                    $level = $enchantment["Level"];

                    /** @var Enchantment $enchantment */
                    $enchantment = EnchantmentIdMap::getInstance()->fromId($id);
                    if (is_null($enchantment)) continue;

                    $instance = new EnchantmentInstance($enchantment, $level);
                    $itemInstance->addEnchantment($instance);
                }
            }

            $validItems[] = $itemInstance;
        }

        return new Kit($name, $validItems, $desc, $type, $cooldown, $perm);
    }
}
