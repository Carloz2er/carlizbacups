<?php

namespace dev\d4y\kits\manager;

use DayKoala\inventory\action\WindowTransaction;
use DayKoala\inventory\Window;
use DayKoala\inventory\WindowFactory;
use DayKoala\Windowy;
use dev\d4y\kits\Kits;
use dev\d4y\kits\objects\Kit;
use pocketmine\item\ItemFactory;
use pocketmine\item\ItemIds;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

class WindowManager
{

    public static function showKits(Player $player, Window &$inventory, int $type = Kit::TYPE_BASIC): void
    {
        $slots = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17];

        $index = 0;
        /** @var Kit $kit */
        foreach (KitManager::get()->getKits() as $kit) {
            if ($kit->getType() != $type) continue;

            $hasPerm = $kit->verify($player);
            $cooldown = KitManager::get()->getCooldown($kit, $player) - time();
            $cooldown = $cooldown <= 0 ? "Sem countdown" : $kit->formatTime($cooldown);

            $color = $hasPerm ? "§a" : "§c";

            $name  = "§r{$color} > {$kit->getName()}\n\n";
            $name .= "§7* Descrição: {$kit->getDescription()} \n";
            $name .= "§7* Countdown: {$kit->formatTime($kit->getCooldown())} §8($cooldown) \n";

            $item = ItemFactory::getInstance()->get($hasPerm || $cooldown != "§7Sem cooldown§8" ? ItemIds::CHEST : ItemIds::BARRIER);
            $item->setCustomName($name);

            $inventory->setItem($slots[$index++], $item, function (WindowTransaction $action) use ($kit) {
                $action->cancel();

                $kit->giveTo($action->getPlayer());

                $action->getPlayer()->setCurrentWindow(Windowy::getWindow(WindowFactory::DOUBLE_CHEST));
            });
        }

        if ($index == 0) {
            $noitem = ItemFactory::getInstance()->get(218, 14);
            $noitem->setCustomName("§r§cNão tem nenhum kit disponível!\n\n§7 * Não tem nenhum kit\n   disponível para uso.");

            $inventory->setItem(13, $noitem, fn (WindowTransaction $a) => $a->cancel());
        }

        $back = ItemFactory::getInstance()->get(ItemIds::BARRIER);
        $back->setCustomName("§4§c Voltar ");

        $inventory->setItem(22, $back, function (WindowTransaction $action) {
            $action->cancel();

            $w = $action->getInventory();
            $w->clearAll();

            self::showKitTypes($w);
        });
    }

    public static function showKitTypes(Window &$inventory): void
    {
        $basic = ItemFactory::getInstance()->get(ItemIds::GRASS);
        $basic->setCustomName("§r§8 - Kits básicos\n\n§7 * Clique aqui para \n   ver os kits básicos ");

        $vips = ItemFactory::getInstance()->get(ItemIds::CHEST);
        $vips->setCustomName("§r§5 - Kits VIP\n\n§7 * Clique aqui para \n   ver os kits VIP ");

        $inventory->setItem(15, $vips, function (WindowTransaction $action) {
            $action->cancel();

            $w = $action->getInventory();
            $w->clearAll();

            self::showKits($action->getPlayer(), $w, Kit::TYPE_VIP);
        });

        $inventory->setItem(11, $basic, function (WindowTransaction $action) {
            $action->cancel();

            $w = $action->getInventory();
            $w->clearAll();

            self::showKits($action->getPlayer(), $w, Kit::TYPE_BASIC);
        });
    }
}
