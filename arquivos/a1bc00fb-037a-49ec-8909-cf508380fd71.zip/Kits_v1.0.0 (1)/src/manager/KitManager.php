<?php

namespace dev\d4y\kits\manager;

use dev\d4y\kits\Kits;
use dev\d4y\kits\objects\Kit;
use dev\d4y\kits\utils\KitBuilder;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class KitManager
{

    /** @var array<string,Kit[]> $loadedKits */
    private array $loadedKits;

    /** @var array<string,array<string,int>> $cooldowns*/
    private array $cooldowns;

    /** @var Kits $plugin */
    private Kits $plugin;

    /** @var string $directory */
    private string $directory;

    /** @var KitManager $instance */
    private static KitManager $instance;

    public function __construct(Kits $plugin)
    {
        self::$instance = $this;

        $this->plugin = $plugin;
        $this->loadedKits = array();
        $this->cooldowns = array();

        $this->directory = $plugin->getDataFolder() . 'kits/';

        $this->init();
    }

    private function init(): void
    {
        $this->loadKits();
        $this->loadCooldowns();
    }

    private function loadCooldowns(): void
    {
        $cooldowns = new Config($this->directory . "cooldowns.yml", Config::YAML);
        $loadedCooldowns = 0;

        foreach ($cooldowns->getAll() as $nick => $kits) {
            $playerCooldowns = array();

            foreach ($kits as $name => $time)
                $playerCooldowns[$name] = intval($time);

            $this->cooldowns[$nick] = $playerCooldowns;
            $loadedCooldowns++;
        }

        $this->plugin->getLogger()->notice("Loaded $loadedCooldowns cooldowns");
    }

    private function loadKits(): void
    {
        $loadedKits = 0;

        if (!file_exists($this->directory)) {
            @mkdir($this->directory, 0777, true);

            foreach (['basic/', 'crate/', 'vip/'] as $dir)
                @mkdir($this->directory . $dir, 0777, true);

            $items = array(
                VanillaItems::IRON_SWORD(),
                VanillaItems::GOLDEN_APPLE()->setCount(16)
                    ->setCustomName("Cortesia"),
                VanillaItems::IRON_HELMET(),
                VanillaItems::IRON_CHESTPLATE(),
                VanillaItems::IRON_LEGGINGS(),
                VanillaItems::IRON_BOOTS()
            );

            $name = "PVP";
            $desc = "Um kit feito pra PvP";

            $kit = new Kit($name, $items, $desc);

            $this->addKit($kit);
            $loadedKits++;

            $this->plugin->getLogger()->notice("Loaded $loadedKits kits");
            return;
        }

        foreach (scandir($this->directory) as $file) {
            if ($file == "." || $file == "..") continue;

            $fileInDir = $this->directory . $file;

            if (is_dir($fileInDir)) continue;

            $config = new Config($fileInDir, Config::YAML);

            if (!($config->exists("Name") || $config->exists("Description") || $config->exists("Items") || $config->exists("Type"))) continue;

            $kit = KitBuilder::createKitFromConfig($config);
            $this->addKit($kit);
            $loadedKits++;
        }

        $this->plugin->getLogger()->notice("Loaded $loadedKits kits");
    }

    public function isInCooldown(Kit $kit, Player $player): bool
    {
        return isset($this->cooldowns[$player->getName()][$kit->getName()]) &&
            $this->cooldowns[$player->getName()][$kit->getName()] - time() > 0;
    }

    public function getCooldown(Kit $kit, Player $player): int
    {
        return $this->cooldowns[$player->getName()][$kit->getName()] ?? -1;
    }

    public function getCooldowns(Player $player): ?array
    {
        return $this->cooldowns[$player->getName()] ?? null;
    }

    public function addCooldown(Kit $kit, Player $player): void
    {
        if (!isset($this->cooldowns[$player->getName()])) {
            $this->cooldowns[$player->getName()] = array(
                $kit->getName() => time() + $kit->getCooldown()
            );
            return;
        }

        $this->cooldowns[$player->getName()][$kit->getName()] = time() + $kit->getCooldown();
    }

    public function saveCooldowns(): void
    {
        if (!isset($this->cooldowns)) return;
        $config = new Config($this->directory . "cooldowns.yml", Config::YAML);
        $savedCooldowns = 0;

        foreach ($this->cooldowns as $nick => $kit) {
            $config->set($nick, $kit);
            $savedCooldowns++;
        }

        $config->save();
        $this->plugin->getLogger()->notice("Saved $savedCooldowns cooldowns!");
    }

    public function getKit(string $name): ?Kit
    {
        if (!isset($this->loadedKits[$name])) return null;

        return $this->loadedKits[$name];
    }

    public function getKits(): array
    {
        return array_values($this->loadedKits);
    }

    public function addKit(Kit $kit): void
    {
        $name = strtolower($kit->getName());
        $this->loadedKits[$name] = $kit;
    }

    public function getKitsDirectory(int $type = -1): string
    {
        return $this->directory;
    }

    public static function get(): self
    {
        return self::$instance;
    }
}
