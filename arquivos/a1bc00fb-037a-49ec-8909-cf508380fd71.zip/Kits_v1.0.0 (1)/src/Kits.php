<?php

namespace dev\d4y\kits;

use dev\d4y\kits\commands\CreateKitCommand;
use dev\d4y\kits\commands\KitCommand;
use dev\d4y\kits\commands\PluginCommand;
use dev\d4y\kits\manager\ChestManager;
use dev\d4y\kits\manager\KitManager;
use pocketmine\command\PluginCommand as _PluginCommand;
use pocketmine\plugin\PluginBase;

class Kits extends PluginBase
{

	/** @var array<string,class<?>> $commands */
	private array $commands = array(
		"KitCommand" => KitCommand::class,
		"CreateKitCommand" => CreateKitCommand::class
	);

	/** @var Kits $instance */
	private static Kits $instance;

	/** @var KitManager $kitManager */
	private KitManager $kitManager;

	public function onEnable(): void
	{
		self::$instance = $this;
		$this->getLogger()->info("Starting Kits...");

		$this->kitManager = new KitManager($this);

		foreach ($this->commands as $prefix => $command) {
			$class = new $command;

			if (!$class instanceof PluginCommand) continue;
			$cmd = $this->getCommand($class->name());

			if ($cmd instanceof _PluginCommand) {
				$cmd->setExecutor($class);
				$this->getLogger()->warning("Registered /{$class->name()} ($prefix) with sucess!");
			}
		}
	}

	public function onDisable(): void
	{
		$this->getKitManager()->saveCooldowns();
	}

	public function getKitManager(): KitManager
	{
		return $this->kitManager;
	}

	public static function get(): self
	{
		return self::$instance;
	}
}
